//
//  AppDelegate.h
//  QAS Drug Calculator
//
//  Created by Kurt Lane on 25/08/13.
//  Copyright (c) 2013 kurtlane.com.au. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
