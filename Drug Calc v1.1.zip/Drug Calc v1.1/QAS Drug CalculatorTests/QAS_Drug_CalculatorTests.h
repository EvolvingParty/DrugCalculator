//
//  QAS_Drug_CalculatorTests.h
//  QAS Drug CalculatorTests
//
//  Created by Kurt Lane on 25/08/13.
//  Copyright (c) 2013 kurtlane.com.au. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface QAS_Drug_CalculatorTests : SenTestCase

@end
