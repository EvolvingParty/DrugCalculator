//
//  QAS_Drug_CalculatorTests.m
//  QAS Drug CalculatorTests
//
//  Created by Kurt Lane on 25/08/13.
//  Copyright (c) 2013 kurtlane.com.au. All rights reserved.
//

#import "QAS_Drug_CalculatorTests.h"

@implementation QAS_Drug_CalculatorTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in QAS Drug CalculatorTests");
}

@end
